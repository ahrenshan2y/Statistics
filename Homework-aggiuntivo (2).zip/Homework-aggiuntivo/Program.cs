using System; 
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace HackerSimulation
{
    public class HackerForm : Form
    {
        private TextBox nTextBox, lambdaTextBox, tTextBox, serverCountTextBox;
        private Button simulateButton;
        private Chart chart;
        private Chart histogramChart;
        private Random random = new Random();
        private List<int> finalPenetrationCounts = new List<int>();

        public HackerForm()
        {
            this.Text = "Poisson Attack Simulation";
            this.Size = new Size(1200, 600);

            // TextBox for Time Steps (n)
            Label nLabel = new Label() { Text = "Time Steps (n):", Left = 10, Top = 10 };
            nTextBox = new TextBox() { Left = 150, Top = 10, Width = 100, Text = "100" };

            // TextBox for Lambda
            Label lambdaLabel = new Label() { Text = "Lambda (��):", Left = 10, Top = 40 };
            lambdaTextBox = new TextBox() { Left = 150, Top = 40, Width = 100, Text = "5" };

            // TextBox for Time Period (T)
            Label tLabel = new Label() { Text = "Time Period (T):", Left = 10, Top = 70 };
            tTextBox = new TextBox() { Left = 150, Top = 70, Width = 100, Text = "1" };

            // TextBox for Server Count
            Label serverCountLabel = new Label() { Text = "Servers:", Left = 10, Top = 100 };
            serverCountTextBox = new TextBox() { Left = 150, Top = 100, Width = 100, Text = "500" }; // Default 3 servers

            simulateButton = new Button() { Text = "Click_to_see", Left = 10, Top = 130, Width = 240 };
            simulateButton.Click += SimulateButton_Click;

            this.Controls.Add(nLabel);
            this.Controls.Add(nTextBox);
            this.Controls.Add(lambdaLabel);
            this.Controls.Add(lambdaTextBox);
            this.Controls.Add(tLabel);
            this.Controls.Add(tTextBox);
            this.Controls.Add(serverCountLabel);
            this.Controls.Add(serverCountTextBox);
            this.Controls.Add(simulateButton);

            // Line chart
            chart = new Chart() { Left = 260, Top = 10, Width = 700, Height = 500, BackColor = Color.LightBlue };
            ChartArea chartArea = new ChartArea("LineChart");
            chart.ChartAreas.Add(chartArea);
            chartArea.AxisX.Title = "Time Intervals";
            chartArea.AxisY.Title = "Cumulative Attacks";

            chartArea.AxisX.TitleFont = new Font("Arial", 12, FontStyle.Bold);
            chartArea.AxisY.TitleFont = new Font("Arial", 12, FontStyle.Bold);
            chartArea.BackColor = Color.Azure;
            this.Controls.Add(chart);

            // Histogram
            histogramChart = new Chart() { Left = 970, Top = 10, Width = 200, Height = 500, BackColor = Color.LightGray };
            ChartArea histogramArea = new ChartArea("HistogramChart");
            histogramChart.ChartAreas.Add(histogramArea);
            histogramArea.AxisX.Title = "Total Attacks";
            histogramArea.AxisY.Title = "Frequency";

            histogramArea.AxisX.TitleFont = new Font("Arial", 12, FontStyle.Bold);
            histogramArea.AxisY.TitleFont = new Font("Arial", 12, FontStyle.Bold);
            histogramArea.BackColor = Color.Beige;
            this.Controls.Add(histogramChart);
        }

        private void SimulateButton_Click(object sender, EventArgs e)
        {
            int n = int.Parse(nTextBox.Text); // time intervals
            double lambda = double.Parse(lambdaTextBox.Text); // lambda parameter for Poisson process
            double T = double.Parse(tTextBox.Text); // total time period
            int serverCount = int.Parse(serverCountTextBox.Text); // number of servers
            double dt = T / n; // small time interval

            chart.Series.Clear(); // Clear previous series
            finalPenetrationCounts.Clear(); // Clear previous penetration counts

            for (int server = 0; server < serverCount; server++)
            {
                List<int> attackCounts = new List<int>();
                int cumulativeAttacks = 0;

                for (int i = 0; i < n; i++)
                {
                    // Poisson process attack: Lambda * dt is the probability of an attack in each time interval
                    if (random.NextDouble() < lambda * dt)
                    {
                        cumulativeAttacks += 1;
                    }
                    attackCounts.Add(cumulativeAttacks);
                }

                finalPenetrationCounts.Add(cumulativeAttacks);

                // Line chart: cumulative attacks over time for each server
                Series series = new Series
                {
                    Name = $"Server {server + 1}",
                    ChartType = SeriesChartType.Line,
                    BorderWidth = 2,
                    Color = Color.FromArgb(random.Next(150, 255), random.Next(150, 255), random.Next(150, 255)) // Random color for each server
                };

                for (int i = 0; i < attackCounts.Count; i++)
                {
                    series.Points.AddXY(i + 1, attackCounts[i]);
                }
                chart.Series.Add(series);
            }

            // Update histogram
            UpdateHistogram();
        }

        private void UpdateHistogram()
        {
            histogramChart.Series.Clear();

            // Frequency count for final attack counts
            Dictionary<int, int> frequency = new Dictionary<int, int>();

            foreach (var count in finalPenetrationCounts)
            {
                if (frequency.ContainsKey(count))
                {
                    frequency[count]++;
                }
                else
                {
                    frequency[count] = 1;
                }
            }

            Series histogramSeries = new Series
            {
                Name = "Histogram",
                ChartType = SeriesChartType.Bar,
                BorderWidth = 1,
                Color = Color.LightGreen
            };

            histogramSeries["PointWidth"] = "0.8"; // Adjust bar width

            foreach (var entry in frequency.OrderBy(entry => entry.Key))
            {
                histogramSeries.Points.AddXY(entry.Key, entry.Value);
            }

            histogramChart.Series.Add(histogramSeries);
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new HackerForm());
        }
    }
}


