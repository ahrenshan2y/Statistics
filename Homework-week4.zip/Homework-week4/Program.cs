using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace HackerSimulation
{
    public class HackerForm : Form
    {
        private TextBox nTextBox, tTextBox, serverCountTextBox;
        private Button simulateButton;
        private Chart chart;
        private Chart histogramChart;
        private Random random = new Random();
        private List<int> finalPenetrationCounts = new List<int>();

        public HackerForm()
        {
            this.Text = "Continuous-time random walk simulation";
            this.Size = new Size(1200, 600);

            Label nLabel = new Label() { Text = "TS(Hackers):", Left = 10, Top = 10 };
            nTextBox = new TextBox() { Left = 150, Top = 10, Width = 100, Text = "100" };

            Label tLabel = new Label() { Text = "Rate of Attack :", Left = 10, Top = 40 };
            tTextBox = new TextBox() { Left = 150, Top = 40, Width = 100, Text = "10" };

            Label serverCountLabel = new Label() { Text = "Paths/Servers:", Left = 10, Top = 70 };
            serverCountTextBox = new TextBox() { Left = 150, Top = 70, Width = 100, Text = "50" };

            simulateButton = new Button() { Text = "Simulate", Left = 10, Top = 100, Width = 240 };
            simulateButton.Click += SimulateButton_Click;

            this.Controls.Add(nLabel);
            this.Controls.Add(nTextBox);
            this.Controls.Add(tLabel);
            this.Controls.Add(tTextBox);
            this.Controls.Add(serverCountLabel);
            this.Controls.Add(serverCountTextBox);
            this.Controls.Add(simulateButton);

            chart = new Chart() { Left = 260, Top = 10, Width = 700, Height = 500, BackColor = Color.LightBlue };
            ChartArea chartArea = new ChartArea("LineChart");
            chart.ChartAreas.Add(chartArea);
            chartArea.AxisX.Title = "Steps";
            chartArea.AxisY.Title = "Cumulative Jumps";
            this.Controls.Add(chart);

            histogramChart = new Chart() { Left = 970, Top = 10, Width = 200, Height = 500, BackColor = Color.LightGray };
            ChartArea histogramArea = new ChartArea("HistogramChart");
            histogramChart.ChartAreas.Add(histogramArea);
            histogramArea.AxisX.Title = "Jumps";
            histogramArea.AxisY.Title = "Frequency";
            this.Controls.Add(histogramChart);
        }

        private void SimulateButton_Click(object sender, EventArgs e)
        {
            int n = int.Parse(nTextBox.Text); // Time Steps
            double T = double.Parse(tTextBox.Text); // T
            int serverCount = int.Parse(serverCountTextBox.Text); // Paths or Servers
            double dt = T / n; // Infinitely small time step
            double sqrtDt = Math.Sqrt(dt); // Wiener process step
            chart.Series.Clear();
            finalPenetrationCounts.Clear();

            for (int server = 0; server < serverCount; server++)
            {
                List<double> positions = new List<double>();
                double position = 0;

                for (int i = 0; i < n; i++)
                {
                    // Random walk jumps, step size sqrt(dt), positive or negative direction
                    position += (random.NextDouble() < 0.5 ? sqrtDt : -sqrtDt);
                    positions.Add(position);
                }

                finalPenetrationCounts.Add((int)position);

                // Drawing the path to each server
                Series series = new Series
                {
                    Name = $"Server {server + 1}",
                    ChartType = SeriesChartType.Line,
                    BorderWidth = 2,
                    Color = Color.FromArgb(random.Next(150, 255), random.Next(150, 255), random.Next(150, 255))
                };

                for (int i = 0; i < positions.Count; i++)
                {
                    series.Points.AddXY(i * dt, positions[i]);
                }
                chart.Series.Add(series);
            }

            UpdateHistogram();
        }

        private void UpdateHistogram()
        {
            histogramChart.Series.Clear();
            Dictionary<int, int> frequency = new Dictionary<int, int>();

            foreach (var count in finalPenetrationCounts)
            {
                if (frequency.ContainsKey(count))
                {
                    frequency[count]++;
                }
                else
                {
                    frequency[count] = 1;
                }
            }

            Series histogramSeries = new Series
            {
                Name = "Histogram",
                ChartType = SeriesChartType.Bar,
                Color = Color.LightGreen
            };

            histogramSeries["PointWidth"] = "0.8";

            foreach (var entry in frequency.OrderBy(entry => entry.Key))
            {
                histogramSeries.Points.AddXY(entry.Key, entry.Value);
            }

            histogramChart.Series.Add(histogramSeries);
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new HackerForm());
        }
    }
}


